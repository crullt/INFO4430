//This function is used to point the client-side code to the Google App Script server that handles data requests. Every time the code in Google App Script is modified, the server must be deployed again. When that happens the code returned by the function must be updated.

function gas_deployment_id(){return(
'AKfycbyVnMp6LeO6J5YV4iL8vm9KmzdM9Rzx5oWGgS3R3E9XCGbWYl8CtuCAejYiWVne7RugHA'
)}
