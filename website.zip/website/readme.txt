The client side files for this project consist of:

1: index.html - the main html page for the site
2: app.css - the style sheet that defines the elements of the features of the site
3: session.css - the style sheet that defines the elements of the site related to the login form
4: app.js - the javascript file that contains the code for all of the user features of the site. 
5: data.js - this is a javascript file used to store global variables and contstants. Currently this stores the information to link the Brookers stores to their corresponding primary key in Airtable
6: identity.js - this javascript file contains the code to manage menus according to user permissions. 
7: session.js - this javascript file contains the code for creating and maintaining user accounts. It also handles user logins.
8: config.js - this javascript file is used to point the client side code to the google app script server. It will need to be updated each time the server is deployed.
It is anticipated that student developers will likely only modify the app.js and app.css files for their student projects.

