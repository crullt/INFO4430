// This is for really stable data so we don't have to ask for it every time. Since stores, rarely change and we aren't worried about this information being available to the user, we store the set of stores and their primary key values from Airtable.

store_sequence=[
    "Vineyard",
    "Herriman",
    "Provo"
]

stores={
    reciLXPTeT7X6BpfX:"Herriman",
    recAWRtheFL9hjYa9:"Provo",
    rec9cc4WpKnQrvWe0:"Vineyard",
    Herriman:"reciLXPTeT7X6BpfX",
    Provo:"recAWRtheFL9hjYa9",
    Vineyard:"rec9cc4WpKnQrvWe0"
}